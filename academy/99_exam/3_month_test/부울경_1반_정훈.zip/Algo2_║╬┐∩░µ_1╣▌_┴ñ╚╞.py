# import sys
#
# sys.stdin = open('algo2_sample_in.txt')


from itertools import combinations

T = int(input())
for tc in range(1, T + 1):
    n, s = map(int, input().split())
    lst = list(map(int, input().split()))
    result = s
    cnt = 0
    for i in range(n, 0, -1):  # 다리를 많이 놔야하니까 위에서 부터 확인
        temp = 0  # 비용
        cnt = 0  # 다리 수
        for j in combinations(lst, i):
            if sum(j) < s:  # 가진 비용보다 작게 들면
                if sum(j) < result:  # 똑같은 다리 갯수지만 비용이 작으면
                    result = sum(j)  # 결과값 갱신
                    cnt = i  # 다리 개수 저장
        if cnt != 0:  # 위에서 부터 확인하니 다리 개수가 나와지면 밑에건 더이상 확인 할 필요 없음
            break  # 종료
    print(f'#{tc}', cnt, result)
